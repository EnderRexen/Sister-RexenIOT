/* ============================================================================
   Sister RexenIOT HUD client
   - streams replies over SSE
   - speaks replies through the server TTS (KittenTTS)
   - listens through the Web Speech API
   - drives the reactor visualiser from speech state
   ========================================================================== */

import { initOnScreenKeyboard } from "./osk.js";

const $ = (sel) => document.querySelector(sel);

const state = {
  personalities: [],
  active: null,
  history: [],
  busy: false,
  muted: false,
  listening: false,
  speaking: false,
  ttsEnabled: true,
  audioCtx: null,
  analyser: null,
  sourceNode: null,
  currentAudio: null,
  recognition: null,
  autoSend: true,
  attachments: [],
  config: null,
  osk: null,
};

/* --------------------------------------------------------------- utilities */

function toast(message, kind = "") {
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.textContent = message;
  $("#toasts").appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .4s";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 400);
  }, 4200);
}

async function api(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch { /* non-JSON error body */ }
    throw new Error(detail);
  }
  const type = res.headers.get("content-type") || "";
  return type.includes("json") ? res.json() : res;
}

function setReactor(mode) {
  $("#reactor").dataset.state = mode;
  const label = { idle: "IDLE", listening: "LISTENING", thinking: "PROCESSING", speaking: "SPEAKING" };
  $("#reactor-state").textContent = label[mode] || mode.toUpperCase();
}

/* ------------------------------------------------------- persona selection */

function applyAccent(hex) {
  document.documentElement.style.setProperty("--accent", hex || "#39d0ff");
}

function renderPersonas() {
  const list = $("#persona-list");
  list.innerHTML = "";
  const enabled = state.personalities.filter((p) => p.enabled !== false);
  if (!enabled.length) {
    list.innerHTML = `<li><div class="pl-body"><div class="pl-name">No personalities</div>
      <div class="pl-desc">Add one in the admin panel.</div></div></li>`;
    return;
  }
  for (const p of enabled) {
    const li = document.createElement("li");
    li.setAttribute("role", "option");
    li.setAttribute("aria-selected", String(p.id === state.active?.id));
    li.dataset.id = p.id;
    li.innerHTML = `
      <span class="pl-dot" style="background:${p.accent};box-shadow:0 0 8px ${p.accent}"></span>
      <span class="pl-body">
        <span class="pl-name">${escapeHtml(p.name)}</span>
        <span class="pl-desc">${escapeHtml(p.tagline || p.description || "")}</span>
      </span>`;
    li.addEventListener("click", () => selectPersona(p.id));
    list.appendChild(li);
  }
}

function renderActivePersona() {
  const p = state.active;
  if (!p) return;
  $("#persona-name").textContent = p.name;
  $("#persona-tag").textContent = p.tagline || "";
  $("#persona-dot").style.background = p.accent;
  $("#persona-dot").style.boxShadow = `0 0 10px ${p.accent}`;
  applyAccent(p.accent);
  $("#s-tts").textContent = `${p.voice} · ${p.speed}x`;
}

async function selectPersona(id) {
  const p = state.personalities.find((x) => x.id === id);
  if (!p) return;
  state.active = p;
  state.history = [];          // a new character means a clean conversation
  $("#messages").innerHTML = "";
  renderActivePersona();
  renderPersonas();
  togglePersonaList(false);
  await api(`/admin/personalities/${id}/activate`, { method: "POST" }).catch(() => {});
  greet();
}

function togglePersonaList(show) {
  const list = $("#persona-list");
  const open = show ?? list.hidden;
  list.hidden = !open;
  $("#persona-button").setAttribute("aria-expanded", String(open));
}

/* -------------------------------------------------------------- messaging */

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Minimal markdown: fenced code, inline code, bold, paragraphs. */
function renderMarkdown(text) {
  let html = escapeHtml(text);
  html = html.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/([*_])([^*_]+)\1/g, "<em>$2</em>");
  return html.split(/\n{2,}/).map((p) => `<p>${p.replace(/\n/g, "<br>")}</p>`).join("");
}

function addMessage(role, text, opts = {}) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "YOU" : (state.active?.name || "AI").slice(0, 2).toUpperCase();

  const body = document.createElement("div");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (opts.pending) {
    bubble.innerHTML = `<span class="typing"><i></i><i></i><i></i></span>`;
  } else {
    bubble.innerHTML = renderMarkdown(text);
  }
  body.appendChild(bubble);

  if (role === "assistant" && !opts.pending && text) {
    const meta = document.createElement("div");
    meta.className = "msg-meta";
    const btn = document.createElement("button");
    btn.className = "speak-btn";
    btn.title = "Speak this reply again";
    btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 010 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`;
    btn.addEventListener("click", () => speak(text));
    meta.appendChild(btn);
    meta.appendChild(document.createTextNode(opts.model ? `via ${opts.model}` : ""));
    body.appendChild(meta);
  }

  wrap.append(avatar, body);
  const container = $("#messages");
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  return { wrap, bubble };
}

function addToolChip(tool, ok, preview) {
  const tray = $("#tool-tray");
  tray.hidden = false;
  const li = document.createElement("li");
  li.className = ok ? "ok" : "bad";
  li.textContent = `${tool}${ok ? "" : " failed"}`;
  li.title = preview || "";
  $("#tool-list").appendChild(li);
}

/* ------------------------------------------------------------ speech (TTS) */

async function speak(text, opts = {}) {
  if (state.muted || !state.ttsEnabled || !text.trim()) return;
  try {
    stopSpeaking();
    const res = await fetch("/api/speak", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        personality_id: state.active?.id,
        voice: opts.voice,
        speed: opts.speed,
      }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      toast(body.detail || "Speech failed", "err");
      return;
    }
    const blob = await res.blob();
    const audio = $("#player");
    audio.src = URL.createObjectURL(blob);
    state.currentAudio = audio;
    // The microphone would otherwise pick up her own voice and wake her.
    pauseWakeForSpeech();
    audio.onplay = () => { state.speaking = true; setReactor("speaking"); attachAnalyser(audio); };
    audio.onended = () => {
      state.speaking = false;
      state.currentAudio = null;
      detachAnalyser();
      setReactor("idle");
      resumeWakeAfterSpeech();
    };
    audio.onerror = () => {
      state.speaking = false;
      detachAnalyser();
      setReactor("idle");
      resumeWakeAfterSpeech();
    };
    await audio.play();
    clearAudioBlockedHint();
  } catch (err) {
    // Browsers refuse to play audio until the user has interacted with the page.
    // That is expected on the opening greeting, not an error worth alarming about.
    if (err.name === "NotAllowedError") {
      resumeWakeAfterSpeech();
      showAudioBlockedHint(text);
      return;
    }
    resumeWakeAfterSpeech();
    toast(`Could not play speech: ${err.message}`, "err");
  }
}

function pauseWakeForSpeech() {
  if (WAKE.mode === "off") return;
  WAKE.resumeAfterSpeech = true;
  try { state.recognition.stop(); } catch { /* not running */ }
}

function resumeWakeAfterSpeech() {
  if (!WAKE.resumeAfterSpeech) return;
  WAKE.resumeAfterSpeech = false;
  if (WAKE.mode === "off") return;
  setTimeout(startWakeRecognition, 250);
}

/** Offer a one-tap way to start audio after the browser blocks autoplay. */
function showAudioBlockedHint(pendingText) {
  if ($("#audio-hint")) return;
  const hint = document.createElement("button");
  hint.id = "audio-hint";
  hint.className = "audio-hint";
  hint.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16"><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 010 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg> Tap to enable sound`;
  hint.addEventListener("click", () => {
    clearAudioBlockedHint();
    if (pendingText) speak(pendingText);
  });
  $("#toasts").appendChild(hint);
}

function clearAudioBlockedHint() {
  $("#audio-hint")?.remove();
}

function stopSpeaking() {
  const audio = state.currentAudio;
  if (audio) {
    audio.pause();
    audio.currentTime = 0;
    if (audio.src) URL.revokeObjectURL(audio.src);
  }
  state.speaking = false;
  detachAnalyser();
  setReactor(state.listening ? "listening" : "idle");
}

/* ------------------------------------------------------------ analyser/viz */

function attachAnalyser(audioEl) {
  try {
    if (!state.audioCtx) state.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = state.audioCtx;
    if (ctx.state === "suspended") ctx.resume();
    detachAnalyser();
    state.sourceNode = ctx.createMediaElementSource(audioEl);
    state.analyser = ctx.createAnalyser();
    state.analyser.fftSize = 512;
    state.sourceNode.connect(state.analyser);
    state.analyser.connect(ctx.destination);
  } catch {
    // MediaElementSource can only bind once per element; ignore and fall back
    // to a synthetic waveform so the visualiser still animates.
    state.analyser = null;
  }
}

function detachAnalyser() {
  try { state.sourceNode?.disconnect(); } catch { /* already gone */ }
  state.sourceNode = null;
  state.analyser = null;
}

const viz = $("#viz");
const vizCtx = viz.getContext("2d");
const bars = new Array(48).fill(0);

function drawViz() {
  const w = viz.width, h = viz.height;
  vizCtx.clearRect(0, 0, w, h);
  const accent = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#39d0ff";

  let data = null;
  if (state.analyser) {
    data = new Uint8Array(state.analyser.frequencyBinCount);
    state.analyser.getByteFrequencyData(data);
  }

  const n = bars.length;
  const bw = w / n;
  for (let i = 0; i < n; i++) {
    let target;
    if (data) {
      const idx = Math.floor((i / n) * data.length * 0.65);
      target = data[idx] / 255;
    } else if (state.speaking || state.listening) {
      // Synthetic fallback: a slow travelling wave.
      const t = performance.now() / 260;
      target = Math.abs(Math.sin(t + i * 0.34)) * (state.speaking ? 0.55 : 0.35);
    } else {
      target = 0.035;
    }
    bars[i] += (target - bars[i]) * 0.22;
    const bh = Math.max(2, bars[i] * h * 0.92);
    vizCtx.fillStyle = accent;
    vizCtx.globalAlpha = 0.28 + bars[i] * 0.72;
    const x = i * bw + bw * 0.18;
    const y = (h - bh) / 2;
    vizCtx.beginPath();
    const r = Math.min(bw * 0.32, 3);
    vizCtx.roundRect(x, y, bw * 0.64, bh, r);
    vizCtx.fill();
  }
  vizCtx.globalAlpha = 1;
  requestAnimationFrame(drawViz);
}

function buildTicks() {
  const g = document.getElementById("ticks");
  const cx = 100, cy = 100, r1 = 94, r2 = 100;
  for (let i = 0; i < 60; i++) {
    const a = (i / 60) * Math.PI * 2;
    const long = i % 5 === 0;
    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", cx + Math.cos(a) * r1);
    line.setAttribute("y1", cy + Math.sin(a) * r1);
    line.setAttribute("x2", cx + Math.cos(a) * (long ? r1 - 7 : r1 - 3));
    line.setAttribute("y2", cy + Math.sin(a) * (long ? r1 - 7 : r1 - 3));
    if (!long) line.setAttribute("opacity", "0.15");
    g.appendChild(line);
  }
}

/* --------------------------------------------------------- speech (input) */

/* Wake mode.
 *
 * A browser speech session cannot run indefinitely, so it is restarted on
 * `onend` for as long as wake mode is armed. Three states matter:
 *
 *   asleep   - nothing heard yet, or the session lapsed. Utterances are
 *              scanned for a wake word and otherwise discarded.
 *   awake    - the wake word was heard. Every utterance is sent to the agent
 *              until a sleep word is heard or the idle timer expires.
 *
 * While the agent is speaking its own voice reaches the microphone, so
 * recognition is paused for the duration of playback. That also means a reply
 * cannot wake her, which is the behaviour we want.
 */

const WAKE = {
  mode: "off", // off | asleep | awake
  sessionTimer: null,
  restarts: 0,
  lastActivity: 0,
};

function normalize(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Match a phrase allowing for the recogniser splitting or slurring words. */
function matchesPhrase(transcript, phrase) {
  const said = normalize(transcript);
  const want = normalize(phrase);
  if (!want) return false;
  if (said.includes(want)) return true;

  // Also accept the phrase with no spaces, which is how "hey rexeniot" often
  // arrives ("heyrexeniot").
  const squashed = said.replace(/\s/g, "");
  return squashed.includes(want.replace(/\s/g, ""));
}

function findPhrase(transcript, phrases) {
  return phrases.find((p) => matchesPhrase(transcript, p)) || null;
}

function wakeConfig() {
  return state.config?.voice_input || {};
}

function setWakeMode(mode) {
  WAKE.mode = mode;
  const badge = $("#wake-badge");
  if (badge) {
    badge.hidden = mode === "off";
    badge.dataset.mode = mode;
    badge.textContent = mode === "awake" ? "AWAKE" : mode === "asleep" ? "LISTENING FOR WAKE WORD" : "";
  }
  $("#btn-wake")?.setAttribute("aria-pressed", String(mode !== "off"));
}

function armWakeMode() {
  if (!state.recognition) {
    toast("This browser has no speech recognition. Use Chrome or Edge.", "err");
    return;
  }
  const cfg = wakeConfig();
  if (!cfg.wake_enabled) {
    toast("Wake mode is switched off in the admin panel.", "err");
    return;
  }
  if (WAKE.mode !== "off") {
    disarmWakeMode();
    return;
  }
  setWakeMode("asleep");
  startWakeRecognition();
  toast("Wake mode armed. Say the wake word to begin.", "ok");
}

function disarmWakeMode() {
  clearTimeout(WAKE.sessionTimer);
  setWakeMode("off");
  try { state.recognition.stop(); } catch { /* not running */ }
  toast("Wake mode off.");
}

function startWakeRecognition() {
  if (WAKE.mode === "off") return;
  try {
    state.recognition.start();
  } catch { /* already running; the onend handler will retry */ }
}

function touchWakeSession() {
  WAKE.lastActivity = Date.now();
  clearTimeout(WAKE.sessionTimer);
  const idleMs = (wakeConfig().session_idle_s || 45) * 1000;
  WAKE.sessionTimer = setTimeout(() => {
    if (WAKE.mode === "awake") {
      setWakeMode("asleep");
      speak("Standing by.");
    }
  }, idleMs);
}

function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Build a matcher for a phrase that tolerates the recogniser running words
 * together ("hey rexeniot" arriving as "heyrexeniot"). Input is normalised to word
 * characters and single spaces first, so no word boundaries are needed.
 */
function phraseRegex(phrase) {
  const words = normalize(phrase).split(" ").filter(Boolean).map(escapeRegex);
  if (!words.length) return null;
  return new RegExp(words.join("\\s*"), "i");
}

/** Remove a wake word from an utterance and return the command that follows. */
function stripWakeWord(transcript) {
  const cfg = wakeConfig();
  const said = normalize(transcript);
  for (const word of cfg.wake_words || []) {
    const re = phraseRegex(word);
    if (!re) continue;
    const match = re.exec(said);
    if (match) {
      return said.slice(match.index + match[0].length).trim();
    }
  }
  return "";
}

function initRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;
  const rec = new SR();
  rec.continuous = true;
  rec.interimResults = true;
  rec.lang = wakeConfig().language || "en-US";

  rec.onstart = () => {
    state.listening = true;
    $("#btn-mic").setAttribute("aria-pressed", "true");
    $("#listen-hint").hidden = false;
    setReactor(WAKE.mode === "awake" ? "listening" : "idle");
  };

  rec.onresult = (event) => {
    let finalText = "", interim = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const chunk = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalText += chunk;
      else interim += chunk;
    }
    const heard = (finalText || interim).trim();

    if (WAKE.mode !== "off") {
      handleWakeUtterance(heard, Boolean(finalText));
      return;
    }

    // Manual push-to-talk.
    $("#input").value = heard;
    autoGrow($("#input"));
    if (finalText && state.autoSend) {
      rec.stop();
      setTimeout(send, 120);
    }
  };

  rec.onerror = (event) => {
    if (event.error === "not-allowed") {
      toast("Microphone permission denied.", "err");
      disarmWakeMode();
    } else if (event.error === "no-speech" || event.error === "aborted") {
      // Routine in a long-lived session; the onend handler restarts it.
    } else if (event.error === "network") {
      // Chrome's recogniser needs the network; warn once rather than looping.
      if (WAKE.restarts < 3) toast("Speech recognition lost its network connection.", "err");
    } else if (WAKE.mode === "off") {
      toast(`Speech input error: ${event.error}`, "err");
    }
  };

  rec.onend = () => {
    state.listening = false;
    $("#btn-mic").setAttribute("aria-pressed", "false");
    $("#listen-hint").hidden = true;

    // A browser session ends on its own after a pause. Restart it so wake mode
    // keeps listening, but back off if restarts are failing in a tight loop.
    if (WAKE.mode !== "off") {
      WAKE.restarts += 1;
      const delay = WAKE.restarts > 20 ? 1500 : 120;
      if (WAKE.restarts > 40) {
        toast("Wake mode stopped after repeated restarts. Check the microphone.", "err");
        setWakeMode("off");
        return;
      }
      setTimeout(startWakeRecognition, delay);
      if (!state.speaking) setReactor("idle");
      return;
    }

    if (!state.speaking) setReactor("idle");
  };

  rec.onaudiostart = () => { WAKE.restarts = 0; };
  return rec;
}

function handleWakeUtterance(heard, isFinal) {
  const cfg = wakeConfig();
  if (!heard) return;

  if (WAKE.mode === "asleep") {
    // Show what was heard so the user can tell the microphone is live.
    $("#listen-hint").hidden = false;
    if (!isFinal) return;

    const hit = findPhrase(heard, cfg.wake_words || []);
    if (!hit) return;

    setWakeMode("awake");
    touchWakeSession();
    const remainder = stripWakeWord(heard);
    if (cfg.acknowledge !== false && cfg.acknowledgement) {
      speak(cfg.acknowledgement);
    }
    if (remainder.length > 1) {
      // "hey rexeniot turn on the lights" in one breath.
      setTimeout(() => sendText(remainder), cfg.acknowledge !== false ? 900 : 0);
    }
    return;
  }

  // Awake: the nearest conversation is treated as addressed to the agent.
  if (!isFinal) {
    $("#input").value = heard;
    autoGrow($("#input"));
    return;
  }

  touchWakeSession();
  const sleep = findPhrase(heard, cfg.sleep_words || []);
  if (sleep) {
    setWakeMode("asleep");
    $("#input").value = "";
    autoGrow($("#input"));
    speak("Going quiet.");
    return;
  }

  const command = stripWakeWord(heard) || heard;
  if (command.trim().length < 2) return;
  $("#input").value = "";
  autoGrow($("#input"));
  sendText(command.trim());
}

function toggleListening() {
  if (!state.recognition) {
    toast("This browser has no speech recognition. Use Chrome or Edge, or type instead.", "err");
    return;
  }
  if (WAKE.mode !== "off") {
    disarmWakeMode();
    return;
  }
  if (state.listening) {
    state.recognition.stop();
  } else {
    stopSpeaking();
    try { state.recognition.start(); } catch { /* already started */ }
  }
}

/* ------------------------------------------------------------- attachments */

/* Files are uploaded as soon as they are picked, so the agent has them indexed
 * before the message is sent. The returned ids ride along with the chat call.
 */

function renderAttachments() {
  const strip = $("#attach-strip");
  strip.innerHTML = "";
  strip.hidden = state.attachments.length === 0;
  for (const file of state.attachments) {
    const chip = document.createElement("span");
    chip.className = `attach-chip ${file.error ? "err" : ""}`;
    chip.title = file.summary || file.name;
    chip.innerHTML = `<span class="attach-name"></span><button type="button" class="attach-x" aria-label="Remove">×</button>`;
    chip.querySelector(".attach-name").textContent =
      file.error ? `${file.name} — ${file.error}` : `${file.name} · ${file.kind}`;
    chip.querySelector(".attach-x").addEventListener("click", () => {
      state.attachments = state.attachments.filter((f) => f !== file);
      if (file.id) api(`/uploads/${file.id}`, { method: "DELETE" }).catch(() => {});
      renderAttachments();
    });
    strip.appendChild(chip);
  }
}

async function uploadFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;

  const form = new FormData();
  for (const file of files) form.append("files", file);
  form.append("session", "default");

  toast(`Reading ${files.length} file${files.length > 1 ? "s" : ""}…`);
  try {
    const res = await fetch("/api/uploads", { method: "POST", body: form });
    const body = await res.json();
    if (!res.ok) throw new Error(body.detail || `HTTP ${res.status}`);
    for (const file of body.files || []) state.attachments.push(file);
    for (const err of body.errors || []) toast(err, "err");
    renderAttachments();
    const ok = (body.files || []).length;
    if (ok) toast(`${ok} file${ok > 1 ? "s" : ""} ready. Ask away.`, "ok");
  } catch (err) {
    toast(`Upload failed: ${err.message}`, "err");
  }
}

/* ------------------------------------------------------------ send / stream */

function autoGrow(el) {
  el.style.height = "auto";
  el.style.height = `${Math.min(el.scrollHeight, 148)}px`;
}

async function send() {
  const input = $("#input");
  const text = input.value.trim();
  if (!text && !state.attachments.length) return;
  input.value = "";
  autoGrow(input);
  return sendText(text);
}

/** Send a message that did not come from the textarea (e.g. a spoken command). */
async function sendText(text) {
  if (state.busy) return;
  const clean = (text || "").trim();
  const attachments = state.attachments.filter((f) => f.id).map((f) => f.id);
  if (!clean && !attachments.length) return;

  state.busy = true;
  $("#btn-send").disabled = true;
  setReactor("thinking");
  $("#tool-list").innerHTML = "";
  $("#tool-tray").hidden = false;

  const shown = attachments.length
    ? `${clean}${clean ? "\n\n" : ""}📎 ${state.attachments.map((f) => f.name).join(", ")}`
    : clean;
  addMessage("user", shown);
  state.history.push({ role: "user", content: shown });
  state.attachments = [];
  renderAttachments();
  const { bubble } = addMessage("assistant", "", { pending: true });

  let accumulated = "";

  try {
    const res = await fetch("/api/chat/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: clean,
        personality_id: state.active?.id,
        history: state.history.slice(-24),
        speak: true,
        attachments,
      }),
    });
    if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let speechText = null;
    let finished = false;

    while (!finished) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split("\n\n");
      buffer = parts.pop() ?? "";
      for (const part of parts) {
        const line = part.split("\n").find((l) => l.startsWith("data:"));
        if (!line) continue;
        let event;
        try { event = JSON.parse(line.slice(5).trim()); } catch { continue; }

        if (event.type === "token") {
          accumulated += event.text;
          bubble.innerHTML = renderMarkdown(accumulated);
          bubble.classList.add("cursor");
          $("#messages").scrollTop = $("#messages").scrollHeight;
        } else if (event.type === "attachments") {
          for (const file of event.files || []) addToolChip("read_file", true, file.summary);
        } else if (event.type === "tool") {
          addToolChip(event.tool, event.ok, event.result);
        } else if (event.type === "status") {
          if (event.message.includes("speech")) setReactor("speaking");
        } else if (event.type === "speech") {
          speechText = event.speak_text;
        } else if (event.type === "speech_error") {
          toast(event.message, "err");
        } else if (event.type === "error") {
          throw new Error(event.message);
        } else if (event.type === "done") {
          accumulated = event.text || accumulated;
        } else if (event.type === "complete") {
          finished = true;
        }
      }
    }

    bubble.classList.remove("cursor");
    bubble.innerHTML = renderMarkdown(accumulated || "(no reply)");
    state.history.push({ role: "assistant", content: accumulated });
    if (speechText) speak(speechText);
    else if (accumulated) speak(accumulated);
  } catch (err) {
    bubble.innerHTML = `<p style="color:var(--err)">${escapeHtml(err.message)}</p>`;
    toast(err.message, "err");
    setReactor("idle");
  } finally {
    state.busy = false;
    $("#btn-send").disabled = false;
    if (!state.speaking) setReactor("idle");
    trimHistory();
  }
}

function trimHistory() {
  if (state.history.length > 40) state.history = state.history.slice(-40);
}

/* ------------------------------------------------------------------ status */

async function refreshStatus() {
  try {
    const s = await api("/status");
    state.ttsEnabled = s.tts?.state !== "disabled";
    $("#s-model").textContent = s.llm?.model || "not set";
    $("#s-tools").textContent = s.tools_enabled ? `${s.tools_enabled ? "on" : "off"}` : "off";
    $("#s-home").textContent = s.tools_enabled ? "ready" : "off";
    $("#brand-sub").textContent = s.hardware || "local agent";

    const llmPill = $("#llm-pill");
    llmPill.className = `pill ${s.llm?.configured ? "ok" : "warn"}`;
    llmPill.querySelector("span").textContent = s.llm?.model || s.llm?.provider || "no model";

    const ttsPill = $("#tts-pill");
    const ttsOk = s.tts?.state === "ready";
    ttsPill.className = `pill ${ttsOk ? "ok" : "warn"}`;
    ttsPill.querySelector("span").textContent = s.tts?.tier ? `${s.tts.tier} tts` : "tts loading";

    if (s.personality && (!state.active || state.active.id !== s.personality.id)) {
      state.active = s.personality;
      renderActivePersona();
    }
  } catch { /* status is best-effort */ }
}

async function refreshReminders() {
  try {
    const r = await api("/reminders");
    const block = $("#reminder-block");
    const list = $("#reminders");
    const items = [...(r.pending || []), ...(r.fired || [])];
    block.hidden = items.length === 0;
    list.innerHTML = "";
    for (const t of items) {
      const li = document.createElement("li");
      li.textContent = t.label ? `${t.label} (${t.seconds}s)` : t.text;
      list.appendChild(li);
    }
  } catch { /* ignore */ }
}

/* -------------------------------------------------------------------- boot */

async function greet() {
  try {
    const g = await api(`/greeting${state.active ? `?personality_id=${state.active.id}` : ""}`);
    addMessage("assistant", g.text);
    state.history.push({ role: "assistant", content: g.text });
    if (g.speech?.speak_text) speak(g.speech.speak_text);
  } catch { /* a missing greeting should not block the UI */ }
}

async function loadPersonalities() {
  const data = await api("/admin/personalities").catch(async () => {
    // Admin token may gate the route; fall back to reading it from status.
    const s = await api("/status");
    return { personalities: [s.personality], active: s.personality?.id };
  });
  state.personalities = data.personalities || [];
  state.active = state.personalities.find((p) => p.id === data.active) || state.personalities[0] || null;
  renderActivePersona();
  renderPersonas();
}

function wireEvents() {
  $("#form").addEventListener("submit", (e) => { e.preventDefault(); send(); });

  $("#input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  });
  $("#input").addEventListener("input", (e) => autoGrow(e.target));
  // Keep the soft keyboard's cursor where the user last left the caret, so soft
  // keys insert at the right spot even when the field is not focused.
  ["click", "keyup", "select"].forEach((type) =>
    $("#input").addEventListener(type, () => state.osk?.syncCaret()));
  $("#input").addEventListener("paste", (e) => {
    const files = Array.from(e.clipboardData?.files || []);
    if (files.length) { e.preventDefault(); uploadFiles(files); }
  });

  $("#btn-send").addEventListener("click", send);
  $("#btn-mic").addEventListener("click", toggleListening);
  $("#btn-wake")?.addEventListener("click", armWakeMode);

  $("#btn-attach").addEventListener("click", () => $("#file-input").click());
  $("#file-input").addEventListener("change", (e) => {
    uploadFiles(e.target.files);
    e.target.value = "";
  });

  $("#btn-mute").addEventListener("click", () => {
    state.muted = !state.muted;
    $("#btn-mute").setAttribute("aria-pressed", String(state.muted));
    if (state.muted) stopSpeaking();
    toast(state.muted ? "Spoken replies muted." : "Spoken replies on.", "ok");
  });

  $("#btn-admin").addEventListener("click", () => { window.location.href = "/admin"; });

  // The soft keyboard is optional and never opens itself; the toggle is offered
  // on every device so a touch screen or a kiosk can reach it, and a desktop
  // user can still call it up deliberately.
  state.osk = initOnScreenKeyboard({
    input: $("#input"),
    toggleButton: $("#btn-keyboard"),
    panel: $("#osk"),
    onChange: () => autoGrow($("#input")),
  });
  $("#btn-keyboard")?.addEventListener("click", () => state.osk?.toggle());

  initFullscreen();

  $("#persona-button").addEventListener("click", () => togglePersonaList());
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".persona-picker")) togglePersonaList(false);
  });

  // Drop files anywhere to attach them.
  ["dragenter", "dragover"].forEach((type) =>
    document.addEventListener(type, (e) => {
      if (!e.dataTransfer?.types?.includes("Files")) return;
      e.preventDefault();
      document.body.classList.add("dropping");
    })
  );
  document.addEventListener("dragleave", (e) => {
    if (!e.relatedTarget) document.body.classList.remove("dropping");
  });
  document.addEventListener("drop", (e) => {
    document.body.classList.remove("dropping");
    if (!e.dataTransfer?.files?.length) return;
    e.preventDefault();
    uploadFiles(e.dataTransfer.files);
  });

  // Hold-to-talk on the space bar when the input is empty.
  document.addEventListener("keydown", (e) => {
    if (e.code === "Space" && e.target === document.body && !state.listening) {
      e.preventDefault();
      toggleListening();
    }
    // Escape drops out of a wake session without reaching for the mouse.
    if (e.key === "Escape" && WAKE.mode === "awake") {
      setWakeMode("asleep");
      toast("Back to wake-word listening.");
    }
  });
}

/** Load the public config the HUD needs: voice input and wake settings. */
async function loadPublicConfig() {
  try {
    state.config = await api("/config");
  } catch {
    state.config = {};
  }
  const vi = state.config.voice_input || {};
  state.autoSend = vi.auto_send !== false;
  if (state.recognition && vi.language) state.recognition.lang = vi.language;

  const btn = $("#btn-wake");
  if (btn) {
    const available = Boolean(state.recognition) && vi.wake_enabled;
    btn.hidden = !available;
    if (available) btn.title = `Listen for the wake word (${(vi.wake_words || []).join(", ")})`;
  }
}

/**
 * Publish the height of the bottom furniture (composer plus soft keyboard) as
 * --dock-h, so the toast stack can sit above it instead of over the Send button.
 */
function trackDockHeight() {
  const dock = $(".composer");
  const osk = $("#osk");
  const topbar = $(".topbar");
  const root = document.documentElement;
  const measure = () => {
    const composer = dock?.getBoundingClientRect().height ?? 0;
    const keyboard = osk && !osk.hidden ? osk.getBoundingClientRect().height : 0;
    root.style.setProperty("--dock-h", `${Math.round(composer + keyboard)}px`);
    // The header wraps to two rows on narrow screens, so the persona dropdown
    // (position: fixed on phones) needs its real bottom edge to sit under it.
    const bar = topbar?.getBoundingClientRect().bottom ?? 0;
    root.style.setProperty("--topbar-b", `${Math.round(bar)}px`);
  };
  measure();
  if (typeof ResizeObserver !== "function") {
    window.addEventListener("resize", measure);
    trackViewportHeight();
    return;
  }
  const ro = new ResizeObserver(measure);
  if (dock) ro.observe(dock);
  if (osk) ro.observe(osk);
  if (topbar) ro.observe(topbar);
  window.addEventListener("resize", measure);
  trackViewportHeight();
}

/**
 * Keep --vh at 1% of the *visible* height. Only the engines without `dvh` read
 * it, where it stands in for the unit the mobile URL bar would otherwise skew.
 */
function trackViewportHeight() {
  const set = () =>
    document.documentElement.style.setProperty("--vh", `${window.innerHeight * 0.01}px`);
  set();
  window.addEventListener("resize", set);
  window.addEventListener("orientationchange", () => setTimeout(set, 120));
  window.visualViewport?.addEventListener("resize", set);
}

/**
 * Full-screen toggle. Hidden on iOS Safari, which has no element-level
 * Fullscreen API: iPhone only exposes it for video. The button therefore appears
 * on desktop, Android and tablets, and the kiosk/TV layouts carry the rest.
 */
function initFullscreen() {
  const btn = $("#btn-fullscreen");
  if (!btn) return;
  const supported =
    !!(document.fullscreenEnabled || document.webkitFullscreenEnabled) &&
    typeof (document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen) === "function";
  if (!supported) return;
  btn.hidden = false;

  const current = () => document.fullscreenElement || document.webkitFullscreenElement || null;
  const sync = () => {
    const on = !!current();
    btn.setAttribute("aria-pressed", String(on));
    btn.title = on ? "Exit full screen" : "Full screen";
  };

  btn.addEventListener("click", async () => {
    try {
      if (current()) {
        await (document.exitFullscreen?.() ?? document.webkitExitFullscreen?.());
      } else {
        const el = document.documentElement;
        await (el.requestFullscreen?.({ navigationUI: "hide" }) ?? el.webkitRequestFullscreen?.());
      }
    } catch (err) {
      // Denied by permissions policy or a non-user gesture; leave the state alone.
      toast(`Full screen unavailable: ${err.message}`, "err");
    }
    sync();
  });

  ["fullscreenchange", "webkitfullscreenchange"].forEach((type) =>
    document.addEventListener(type, sync)
  );
  sync();
}

async function boot() {
  buildTicks();
  drawViz();
  wireEvents();
  trackDockHeight();

  state.recognition = initRecognition();
  if (!state.recognition) $("#btn-mic").title = "Speech input unavailable in this browser";

  const status = $("#boot-status");
  try {
    status.textContent = "Loading personalities…";
    await loadPersonalities();
    status.textContent = "Checking systems…";
    await loadPublicConfig();
    await refreshStatus();
    $("#boot").classList.add("done");
    $("#app").hidden = false;
    greet();
  } catch (err) {
    status.textContent = `Startup problem: ${err.message}`;
    toast(`Startup problem: ${err.message}`, "err");
    $("#app").hidden = false;
  }

  setInterval(refreshStatus, 20000);
  setInterval(refreshReminders, 15000);
  refreshReminders();
}

boot();
